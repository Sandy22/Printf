# ft_printf
42 projects

I had to code my own version of printf.
To be completely honest, if I had to do it now, I would have done the project a bit differently.
