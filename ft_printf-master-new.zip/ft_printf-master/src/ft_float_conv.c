/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_float_conv.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gguiulfo <gguiulfo@student.42.us.org>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/04/09 19:15:51 by gguiulfo          #+#    #+#             */
/*   Updated: 2017/04/13 14:31:01 by gguiulfo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libftprintf.h>

void	ft_float_conv(t_vector *vector, t_info *pfinfo, va_list ap)
{
	(void)vector;
	(void)pfinfo;
	(void)ap;
}
